'use strict';
const {dialogflow} = require('actions-on-google');
const functions = require('firebase-functions');
const app = dialogflow({debug: true});
app.intent('favorite color', (conv, {color}) => {
    const luckyNumber = Math.floor(Math.random() * 10);
    conv.close(`Tu número de la suerte es ${luckyNumber}, para el color ${color}`);
});
exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);
