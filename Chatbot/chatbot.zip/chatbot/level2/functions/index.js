'use strict';
const {
  dialogflow,
  Permission,
  Suggestions,
  BasicCard,
} = require('actions-on-google');
const functions = require('firebase-functions');
const app = dialogflow({debug: true});

const colorMap = {
  'taco indigo': {
    title: 'Taco Indigo',
    text: 'Taco Indigo es un leve tono azul.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDN1JRbF9ZMHZsa1k/style-color-uiapplication-palette1.png',
      accessibilityText: 'Color Taco Indigo',
    },
    display: 'WHITE',
  },
  'rosado unicornio': {
    title: 'Rosado Unicornio',
    text: 'Rosado Unicornio es una saturación rojiza imaginaria.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDbFVfTXpoaEE5Vzg/style-color-uiapplication-palette2.png',
      accessibilityText: 'Color Rosado Unicornio',
    },
    display: 'WHITE',
  },
  'café gris azul': {
    title: 'Café Gris Azul',
    text: 'En días lluviosos, Café Gris Azul trae a la mente tu cafetería favorita.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDZUdpeURtaTUwLUk/style-color-colorsystem-gray-secondary-161116.png',
      accessibilityText: 'Color Café Gris Azul',
    },
    display: 'WHITE',
  },
};

app.intent('Default Welcome Intent', (conv) => {
  conv.ask(new Permission({
    context: 'Hola, para conocerte mejor',
    permissions: 'NAME',
  }));
});

app.intent('actions_intent_PERMISSION', (conv, params, permissionGranted) => {
  if (!permissionGranted) {
    conv.ask(`OK, no hay problema. ¿Cuál es tu color favorito?`);
    conv.ask(new Suggestions('Azul', 'Rojo', 'Verde'));
  } else {
    conv.data.userName = conv.user.name.display;
    conv.ask(`Gracias, ${conv.data.userName}. ¿Cuál es tu color favorito?`);
    conv.ask(new Suggestions('Azul', 'Rojo', 'Verde'));
  }
});


app.intent('favorite color', (conv, {color}) => {
  const luckyNumber = Math.floor(Math.random() * 10);
  const audioSound = 'https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg';
  if(conv.data.userName) {
    conv.ask(`<speak>${conv.data.userName}. Tu número de la suerte es ` +
      `${luckyNumber}.<audio src="${audioSound}"></audio>` +
      `¿Quisieras oir algunos colores falsos?</speak>`);
    conv.ask(new Suggestions('Sí', 'No'));
  } else {
    conv.ask(`<speak>Tu número de la suerte es ` +
      `${luckyNumber}.<audio src="${audioSound}"></audio>` +
      `¿Quisieras oir algunos colores falsos?</speak>`);
    conv.ask(new Suggestions('Sí', 'No'));
  }
});

app.intent('favorite fake color', (conv, {fakeColor}) => {
  conv.close(`Acá está el color`, new BasicCard(colorMap[fakeColor]));
});

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);
