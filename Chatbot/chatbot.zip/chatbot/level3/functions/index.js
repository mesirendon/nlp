'use strict';
const {
  dialogflow,
  Permission,
  Suggestions,
  BasicCard,
  Carousel,
  Image,
} = require('actions-on-google');
const functions = require('firebase-functions');
const app = dialogflow({debug: true});

const fakeColorCarousel = () => {
  const carousel = new Carousel({
    items: {
      'taco indigo': {
        title: 'Taco Indigo',
        synonyms: ['indigo', 'taco'],
        image: new Image({
          url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDN1JRbF9ZMHZsa1k/style-color-uiapplication-palette1.png',
        alt: 'Taco Indigo es un leve tono azul.',
        }),
      },
      'rosado unicornio': {
        title: 'Rosado Unicornio',
        synonyms: ['rosado', 'unicornio'],
        image: new Image({
          url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDbFVfTXpoaEE5Vzg/style-color-uiapplication-palette2.png',
          alt: 'Rosado Unicornio es una saturación rojiza imaginaria.',
        }),
      },
      'café gris azul': {
        title: 'Café Gris Azul',
        synonyms: ['café', 'gris', 'azul'],
        image: new Image({
          url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDZUdpeURtaTUwLUk/style-color-colorsystem-gray-secondary-161116.png',
          alt: 'En días lluviosos, Café Gris Azul trae a la mente tu cafetería favorita.',
        }),
      },
    }
  });
  return carousel;
}

const colorMap = {
  'taco indigo': {
    title: 'Taco Indigo',
    text: 'Taco Indigo es un leve tono azul.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDN1JRbF9ZMHZsa1k/style-color-uiapplication-palette1.png',
      accessibilityText: 'Color Taco Indigo',
    },
    display: 'WHITE',
  },
  'rosado unicornio': {
    title: 'Rosado Unicornio',
    text: 'Rosado Unicornio es una saturación rojiza imaginaria.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDbFVfTXpoaEE5Vzg/style-color-uiapplication-palette2.png',
      accessibilityText: 'Color Rosado Unicornio',
    },
    display: 'WHITE',
  },
  'café gris azul': {
    title: 'Café Gris Azul',
    text: 'En días lluviosos, Café Gris Azul trae a la mente tu cafetería favorita.',
    image: {
      url: 'https://storage.googleapis.com/material-design/publish/material_v_12/assets/0BxFyKV4eeNjDZUdpeURtaTUwLUk/style-color-colorsystem-gray-secondary-161116.png',
      accessibilityText: 'Color Café Gris Azul',
    },
    display: 'WHITE',
  },
};

app.intent('Default Welcome Intent', (conv) => {
  const name = conv.user.storage.userName;
  if(!name) {
    conv.ask(new Permission({
      context: 'Hola, para conocerte mejor',
      permissions: 'NAME',
    }));
  } else {
    conv.ask(`Hola de nuevo ${name}. ¿Cuál es tu color favorito?`);
  }
});

app.intent('actions_intent_PERMISSION', (conv, params, permissionGranted) => {
  if (!permissionGranted) {
    conv.ask(`OK, no hay problema. ¿Cuál es tu color favorito?`);
    conv.ask(new Suggestions('Azul', 'Rojo', 'Verde'));
  } else {
    conv.user.storage.userName = conv.user.name.display;
    conv.ask(`Gracias, ${conv.user.storage.userName}. ¿Cuál es tu color favorito?`);
    conv.ask(new Suggestions('Azul', 'Rojo', 'Verde'));
  }
});


app.intent('favorite color', (conv, {color}) => {
  const luckyNumber = Math.floor(Math.random() * 10);
  const audioSound = 'https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg';
  if(conv.user.storage.userName) {
    conv.ask(`<speak>${conv.user.storage.userName}. Tu número de la suerte es ` +
      `${luckyNumber}.<audio src="${audioSound}"></audio>` +
      `¿Quisieras oir algunos colores falsos?</speak>`);
    conv.ask(new Suggestions('Sí', 'No'));
  } else {
    conv.ask(`<speak>Tu número de la suerte es ` +
      `${luckyNumber}.<audio src="${audioSound}"></audio>` +
      `¿Quisieras oir algunos colores falsos?</speak>`);
    conv.ask(new Suggestions('Sí', 'No'));
  }
});

app.intent('favorite fake color', (conv, {fakeColor}) => {
  fakeColor = conv.arguments.get('OPTION') || fakeColor;
  conv.ask(`Acá está el color`, new BasicCard(colorMap[fakeColor]));
  if(!conv.screen) {
    conv.ask(colorMap[fakeColor].text);
  }
});

app.intent('actions_intent_NO_INPUT', (conv) => {
  const repromptCount = parseInt(conv.arguments.get('REPROMPT_COUNT'));
  if(repromptCount === 0) {
    conv.ask('¿De qué color quisieras hablar?');
  } else if(repromptCount ===1) {
    conv.ask('Por favor, di el nombre de un color.');
  } else if(conv.arguments.get('IS_FINAL_REPROMPT')) {
    conv.close('Lo siento, pero no estoy entendiendo. ' +
      'Podemos intentar más tarde. Hasta luego.');
  }
});

app.intent('favorite color - yes', (conv) => {
  conv.ask('¿Qué color, taco indigo, rosado unicornio, o café gris azul?');
  if(conv.screen) {
    return conv.ask(fakeColorCarousel());
  }
});

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);
